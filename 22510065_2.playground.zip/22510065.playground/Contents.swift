//Name: Ishwar Raut
//PRN:22510065

import UIKit
//Problem 1
var a=10,b=6;
var add=a+b;
var sub=a-b;
var mul=a*b;
var div=a/b;
print("Addition is \(add)")
print("Subtraction is \(sub)")
print("Multiplication is \(mul)")
print("Division is \(div)\n")

//Problem 2
var i=0;
i+=2;
print("i becomes \(i)");
i-=1;
print("i becomes \(i)");
i*=8;
print("i becomes \(i)");
i/=4;
print("i becomes \(i)\n");

//Problem 3
var X=2,Y=3,Z=4;
print("(X+Y*Z)= \(X+Y*Z)");
print("((X+Y)*Z)= \((X+Y)*Z)\n");

//Problem 4
var num=10;
var double_num=Double(num);
var ans=double_num*5;
print("Double Part \(ans)\n");

//Problem 5
var Num=10.5
var int_num=Int(Num);
print("Integer part of \(Num) is \(int_num)\n");

//Problem 6
var x=7;
if x%2==0{
    print("\(x) is Even\n");
}
else{
    print("\(x) is Odd\n");
}

//Problem 7
var score=87;
if(score>=90){
    print("A grade\n");}
else if score>=80{
            print("B Grade\n");}
else if score>=70{
            print("C Grade\n");}
else if score>=60{
            print("D Grade\n");}
else {
            print("F Grade\n");}

//Problem 8
let predefinedUsername = "user123"
let predefinedPassword = "password123"

let inputUsername = "user123"
let inputPassword = "password123"

if inputUsername == predefinedUsername && inputPassword == predefinedPassword {
    print("Login successful\n")
} else {
    print("Invalid username or password\n")
}

//Problem 9
var day=5;
switch day{
case 1: print("Monday\n");
case 2: print("Tuesday\n");
case 3: print("Wednesday\n");
case 4: print("Thursday\n");
case 5: print("Friday\n");
case 6: print("Saturday\n");
case 7: print("Sunday\n");
default: print("Invalid Day\n");
}

//Problem 10
var p=10,q=8,r=15;
if p>=q && p>=r{
    print("\(p) is greatest\n");
}
else if q>=p && q>=r{
    print("\(q) is greatest\n");
}
else {
    print("\(r) is greatest\n");
}

//Problem 11
var age=19;
var citizenship:Bool=false;
if citizenship==true && age>=18{
    print("You can vote\n");
}
else if(citizenship==false){
    print("You are not a citizen of India\n");
}
else{
    print("Your age is not eligible to vote\n");
}

//Problem 12
var total=4500;
if total>=4000{
    print("Yes you will get a discount of 10%\n");
}
var isStudent=true;
if(isStudent){
    print("You are a student\n");
}
else {
    print("You are a Senior Citizen\n");
}

//Problem 13
let number=1000;
let isSmallNumber=number<10;
print("The value of isSmallNumber is \(isSmallNumber)");

let speedLimit=65;
let currentSpeed=72;
let isSpeeding=currentSpeed>speedLimit;
print("The Vale of isSpeeding is \(isSpeeding)");
print("The type is \(type(of:isSpeeding))\n");

//Problem 14
var Age=21;
switch Age{
case 0..<10: print("Infant\n");
case 11..<20: print("Teenager\n");
case 20..<30: print("Adult\n");
case 30..<60: print("Senior\n");
default: print("You are not a human\n");
}

//Problem 15
var Day="Tuesday";
switch Day{
case "Monday","Tuesday","Wednesday","Thursday","Friday": print("\(Day) is Weekday\n");
case "Saturday","Sunday": print("\(Day) is Weekend\n");
default: print("\(Day) is Invalid Day\n");
}
