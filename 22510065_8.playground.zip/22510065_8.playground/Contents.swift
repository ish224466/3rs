import UIKit

var greeting = "Hello, playground"

var score: Int? = nil  // Initially set to nil
score = 90// Later assign 90
print(score!)  // This will crash with "Unexpectedly found nil while unwrapping an Optional value."

func printOptionalString(value: String?) {
    if let unwrappedValue = value {
        print(unwrappedValue)
    } else {
        print("No value")
    }
}

func halfOfValue(value: Double?) -> Double {
    if let unwrappedValue = value {
        return unwrappedValue / 2
    } else {
        return 0.0
    }
}

var optionalInt: Int? = 42
if let unwrappedInt = optionalInt {
    print(unwrappedInt)  // This will print 42
} else {
    print("Value is nil")
}

class Book {
    var author: String?
    
    init(author: String?) {
        self.author = author
    }
}

let myBook = Book(author: "J.K. Rowling")
print(myBook.author?.uppercased() ?? "No author available")  // Uses optional chaining

func valueForKey(dictionary: [String: Int]?, key: String) -> Int {
    return dictionary?[key] ?? -1
}

func firstWord(sentence: String?) -> String {
    if let sentence = sentence, let firstWord = sentence.split(separator: " ").first {
        return String(firstWord)
    } else {
        return "No words"
    }
}

struct User {
    var email: String?
    
    func getEmail() -> String {
        return email ?? "No email provided"
    }
}

let user = User(email: nil)
print(user.getEmail())  // Prints "No email provided"

class BankAccount {
    var balance: Double
    
    init?(balance: Double) {
        if balance < 0 {
            return nil  // Return nil if the balance is negative
        }
        self.balance = balance
    }
}

struct Usera {
    var username: String?
    
    init?(username: String?) {
        if let username = username, username.count >= 5 {
            self.username = username
        } else {
            return nil  // Return nil if the username is shorter than 5 characters
        }
    }
}
