//
//  ViewController.swift
//  Apple Pie
//
//  Created by Apple Lab 24 on 27/03/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var treeImageView: UIImageView!
    @IBOutlet var CorrectWordLabel: UILabel!
    @IBOutlet var scoreLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

