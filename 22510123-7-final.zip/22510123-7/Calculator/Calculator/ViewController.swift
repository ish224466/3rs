//
//  ViewController.swift
//  Calculator
//
//  Created by Apple Lab 24 on 03/04/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

