//
//  Game.swift
//  Apple pie
//
//  Created by Apple Lab 24 on 04/04/25.
//

import Foundation
//struct Game {
//    var word: String
//    var incorrectMovesRemaining : Int
//    var guessedLetters : [Character]
//
//    mutating func playerGuessed(letter: Character){
//        guessedLetters.append(letter)
//    }
//}
struct Game {
    var word: String
    var incorrectMovesRemaining: Int
    var guessedLetters: [Character]
    
    var formattedWord: String {
        var guessedWord = ""
        for letter in word {
            if guessedLetters.contains(letter) {
                guessedWord += "\(letter)"
            } else {
                guessedWord += "_"
            }
        }
        return guessedWord
    }
    
    mutating func playerGuessed(letter: Character) {
      guessedLetters.append(letter)
      if !word.contains(letter) {
        incorrectMovesRemaining -= 1
      }
    }
}


