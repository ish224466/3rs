//
//  ViewController.swift
//  22510065_app
//
//  Created by Ishwar Raut.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
       //Error 1:When u don't wrap the value of UINavgationController.....
        //navigationController.title="Debugging"
        //Value of optional type 'UINavigationController?' must be unwrapped to refer to member 'title' of wrapped base type 'UINavigationController'
        var names = ["Tammy", "Cole"]

        // Debugging: Print the array before any removals
        print("Initial names: \(names)")

        // Removing elements intentionally (this will cause an error)
        names.removeFirst() // Removes "Tammy"
        print("Final names: \(names)")
        names.removeFirst() //breakpoint set here that is only first name is printed
        print("Final names: \(names)")// Removes "Cole"
       names.removeFirst()// breakpoint set here that will result in empty array and code will run succesfully without executing further part
        print("Final names: \(names)")// Error 2 : Array is empty, will not give any more names

        // Debugging: Print the array after all removals
        print("Final names: \(names)")
    }
}
