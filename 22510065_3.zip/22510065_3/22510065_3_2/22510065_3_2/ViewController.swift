//
//  ViewController.swift
//  22510065_3_2
//
//  Created by Ishwar Raut.
//
import UIKit


class ViewController: UIViewController {
    var lightOn = true

  
    @IBOutlet var lightButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()// Do any additional setup after loading the view.
    }
    fileprivate func updateUI(){   if lightOn
        {
            view.backgroundColor = .white
        lightButton.setTitle("Off" , for: .normal)
        }
        else {
            view.backgroundColor = .black
            lightButton.setTitle("On" , for: .normal)
        }
        
    }

    
    @IBAction func lightButton(_ sender: Any) {
        lightOn.toggle()
        updateUI()
    }
}
