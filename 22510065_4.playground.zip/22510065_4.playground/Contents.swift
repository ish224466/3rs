import UIKit
//Name: Ishwar Raut
//PRN 22510065
var greeting = "Hello, playground"

import Foundation

// 1. Print name and age using string interpolation.
let name = "Alice"
let age = 25
print("\(name) is \(age) years old.")

// 2. Print sum of two numbers using string interpolation.
let num1 = 10
let num2 = 5
print("The sum of \(num1) and \(num2) is \(num1 + num2).")

// 3. Print length of a string.
let text = "Hello, Swift!"
print("The length of the string is \(text.count).")

// 4. Convert string to uppercase and lowercase.
let message = "Hello, Swift!"
let uppercased = message.uppercased()
let lowercased = message.lowercased()
print("Uppercase: \(uppercased)")
print("Lowercase: \(lowercased)")

// 5. Check if a string is empty.
let text2 = ""
if text2.isEmpty {
    print("String is empty")
} else {
    print("String is not empty")
}

// 6. Concatenate two strings.
let firstName = "Alice"
let lastName = "Johnson"
let fullName = firstName + " " + lastName
print(fullName)

// 7. Check if a string starts with "Swift".
let word = "SwiftLanguage"
let startsWithSwift = word.hasPrefix("Swift")
print(startsWithSwift)

// 8. Extract domain extension from website.
// 8. Extract domain extension from website.
let website = "www.example.com"

// Extract domain extension (".com")
let domainExtension = String(website.suffix(4))
print(domainExtension)

// 9. Check if "brown" is present in the text.
let text3 = "The quick brown fox"
let containsBrown = text3.contains("brown")
print(containsBrown)

// 10. Compare two strings case-sensitively.
let str1 = "Hello"
let str2 = "hello"
let areEqual = str1 == str2
print(areEqual)

// 11. Compare two strings ignoring case.
let areEqualIgnoringCase = str1.lowercased() == str2.lowercased()
print(areEqualIgnoringCase)

// 12. Check if today is weekend (Saturday or Sunday).
func isWeekend() -> Bool {
    let today = Calendar.current.component(.weekday, from: Date())
    return today == 7 || today == 1
}
print(isWeekend())

// 13. Check if a number is even.
func isEven(number: Int) -> Bool {
    return number % 2 == 0
}
print(isEven(number: 4))  // true
print(isEven(number: 7))  // false

// 14. Convert Celsius to Fahrenheit.
func celsiusToFahrenheit(celsius: Double) -> Double {
    return (celsius * 9/5) + 32
}
print(celsiusToFahrenheit(celsius: 25))  // 77.0

// 15. Calculate power of a number (default exponent = 2).
func power(base: Int, exponent: Int = 2) -> Int {
    return Int(pow(Double(base), Double(exponent)))
}
print(power(base: 3))    // 9 (default exponent is 2)
print(power(base: 2, exponent: 3))  // 8

// 16. Calculate area of a rectangle.
func calculateArea(of length: Double, and width: Double) -> Double {
    return length * width
}
print(calculateArea(of: 10, and: 5))  // 50.0

// 17. Greet a person by name.
func greet(person name: String) {
    print("Hello, \(name)!")
}
greet(person: "Alice")  // Hello, Alice!

// 18. Print a message multiple times.
func repeatMessage(_ message: String, _ times: Int) {
    for _ in 1...times {
        print(message)
    }
}
repeatMessage("Swift", 3)

// 19. Return the larger of two numbers.
func maxOfTwo(a: Int, b: Int) -> Int {
    return a > b ? a : b
}
print(maxOfTwo(a: 8, b: 12))  // 12

// 20. Calculate factorial of a number.
func factorial(n: Int) -> Int {
    if n == 0 || n == 1 {
        return 1
    }
    return n * factorial(n: n - 1)
}
print(factorial(n: 5))  // 120
